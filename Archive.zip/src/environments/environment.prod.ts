export const environment = {
  production: true,
  // backendUrl: '', // Ruta relativa a la API
  backendUrl: '/ecf/', // Ruta relativa a la API
  firebase: {
    apiKey: 'AIzaSyDW4qeVifWDleFZFgKfK4XPLpzJS668egE',
    authDomain: 'ecf-cert.firebaseapp.com',
    projectId: 'ecf-cert',
    storageBucket: 'ecf-cert.firebasestorage.app',
    messagingSenderId: '170320004110',
    appId: '1:170320004110:web:2256e4ae1422d7b71fe85f',
  },
};
