import { Component, OnInit } from '@angular/core';

declare var $: any;

@Component({
  selector: 'app-public',
  templateUrl: './public.page.html',
  styleUrls: ['./public.page.scss']
})
export class PublicPage {


}
