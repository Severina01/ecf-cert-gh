# EcfCert

## 1. Running PHP Server For Signature

code: `php -S localhost:8000 -t /Users/mellomarziano/Documents/Projects/starsoftProjects/php-dgii-signer/src/`
